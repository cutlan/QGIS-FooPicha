
def classFactory(iface):
    from .foopicha import foopicha
    return foopicha(iface)


